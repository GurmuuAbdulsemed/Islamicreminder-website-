// Web Speech API + Quran audio
const recognition = new webkitSpeechRecognition();
recognition.lang = 'en-US';

const quranAudio = new Audio();
const verses = {
  'play al fatiha': 'https://everyayah.com/data/Alafasy_64kbps/001001.mp3',
  'play ayatul kursi': 'https://everyayah.com/data/Alafasy_64kbps/002255.mp3'
};

recognition.onresult = (event) => {
  const command = event.results[0][0].transcript.toLowerCase();
  if (verses[command]) {
    quranAudio.src = verses[command];
    quranAudio.play();
  }
};

document.getElementById('voice-btn').addEventListener('click', () => {
  recognition.start();
});